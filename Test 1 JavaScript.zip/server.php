<?php
header("Content-type: text/html; charset=utf-8");
$response = $_GET['gender'];
switch ($response) {
    case "male":
        $html = '<div class="fromphp">
		<label>Номер военного билета</label>
		<input type="text" />
		<label>Серия паспорта</label>
		<input type="text" />
		</div>';
        break;
    case "female":
        $html = '<div class="fromphp">
		<label>Рост</label>
		<input type="text" />
		<label>Вес</label>
		<select>
			<option>40 кг</option>
			<option>50 кг</option>
			<option>51 кг</option>
			<option>52 кг</option>
		</select>
		<label>Размер груди</label>
		<input type="radio" name="chest" />3
		<input type="radio" name="chest" />4
		<input type="radio" name="chest" />5		
		</div>';
        break;
    default:
        $html = "";
}
echo $html;
?>